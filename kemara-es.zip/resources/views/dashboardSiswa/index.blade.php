@extends('layouts.user_type.auth')
@section('title', 'Kemara-ES | Dashboard Siswa')

@section('content')
@endsection