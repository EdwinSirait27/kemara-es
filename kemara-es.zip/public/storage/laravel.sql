/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 10.4.32-MariaDB : Database - laravel
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*Table structure for table `failed_jobs` */

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `failed_jobs` */

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `migrations` */

insert  into `migrations`(`id`,`migration`,`batch`) values 
(1,'2014_10_12_100000_create_password_resets_table',1),
(2,'2019_08_19_000000_create_failed_jobs_table',1),
(3,'2019_12_14_000001_create_personal_access_tokens_table',1),
(4,'2024_11_28_111638_create_users_table',1),
(5,'2024_11_28_161912_create_tb_guru_table',1),
(6,'2024_11_28_161918_create_tb_siswa_table',1),
(7,'2024_11_28_162910_add_guru_id_siswa_id_colom_user_table',1),
(8,'2024_12_09_155906_create_tb_pengumuman_table',1),
(9,'2024_12_10_132926_create_tb_matapelajaran_table',1),
(10,'2024_12_10_132935_create_tb_kelas_table',1),
(11,'2024_12_10_132952_create_tb_ekstrakulikuler_table',1),
(12,'2024_12_10_133006_create_tb_organisasi_table',1),
(13,'2024_12_10_152925_create_tb_kurikulum_table',1),
(14,'2024_12_11_071754_create_tb_tahunakademik_table',1),
(15,'2024_12_12_043906_create_tb_tombol_table',1),
(16,'2024_12_12_124823_create_tb_osis_table',1),
(17,'2024_12_14_022435_create_tb_hasil_voting_table',1),
(18,'2024_12_14_195145_create_tb_voting_table',1),
(19,'2024_12_19_134023_create_tb_siswaarsip_table',1),
(20,'2024_12_21_222006_create_tb_datamengajar_table',2),
(21,'2024_12_21_224122_create_tb_datamengajar_table',3),
(22,'2024_12_22_170033_create_tb_kelas_siswa_table',4),
(23,'2024_12_22_171542_add_ket_colom_tb_kelas_siswa_table',5),
(24,'2024_12_24_114458_create_tb_pengaturan_kelas_table',6),
(25,'2024_12_24_122136_create_tb_pengaturankelas_siswa_table',6),
(26,'2024_12_24_122144_create_tb_pengaturankelas_datamengajar_table',6),
(27,'2025_01_02_154250_add_tahunakademik_id_colom_tb_kelas_table',7),
(28,'2025_01_02_201518_create_tb_ekstra_siswa_table',8),
(29,'2025_01_02_201605_create_tb_organisasi_siswa_table',9),
(30,'2025_01_04_161201_add_tahunakademik_id_colom_tb_ekstrakulikuler_table',10),
(31,'2025_01_04_161216_add_tahunakademik_id_colom_tb_organisasi_table',10),
(32,'2025_01_18_032252_add_foto_colom_tb_ekstrakulikuler_table',11),
(33,'2025_01_18_032305_add_foto_colom_tb_organisasi_table',12),
(34,'2025_01_19_124455_add_status_colom_tb_pengaturan_kelas_table',12),
(35,'2025_01_22_100801_create_tb_pembayaran_table',13),
(36,'2025_01_22_101903_create_tb_pembayaran_table',14),
(37,'2025_01_22_123727_add_tanggalbukti_colom_tb_pembayaran_table',15),
(38,'2025_01_23_034520_create_tb_kepalasekolah_table',16),
(39,'2025_01_25_092541_create_tb_youtube_table',17),
(40,'2025_01_25_113015_create_tb_berita_table',18),
(41,'2025_01_25_114153_create_tb_berita_table',19),
(42,'2025_01_27_105408_create_tb_profile_table',20);

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `personal_access_tokens` */

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `personal_access_tokens` */

/*Table structure for table `tb_berita` */

DROP TABLE IF EXISTS `tb_berita`;

CREATE TABLE `tb_berita` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `header` varchar(255) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `gambar1` varchar(255) DEFAULT NULL,
  `gambar2` varchar(255) DEFAULT NULL,
  `gambar3` varchar(255) DEFAULT NULL,
  `gambar4` varchar(255) DEFAULT NULL,
  `gambar5` varchar(255) DEFAULT NULL,
  `gambar6` varchar(255) DEFAULT NULL,
  `gambar7` varchar(255) DEFAULT NULL,
  `gambar8` varchar(255) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_berita_user_id_foreign` (`user_id`),
  CONSTRAINT `tb_berita_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_berita` */

insert  into `tb_berita`(`id`,`user_id`,`header`,`body`,`gambar1`,`gambar2`,`gambar3`,`gambar4`,`gambar5`,`gambar6`,`gambar7`,`gambar8`,`status`,`created_at`,`updated_at`) values 
(1,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','halo dunia','nggatau','1737788238_ktp_cristopher_edwin_sirait.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-25 14:57:18','2025-01-25 14:57:18'),
(2,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','halo lagi','khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids khbzkvjbdsjvskzs jsv szdhvusduvosdz uoeahefuuofhouszdvhosz oudszhvuosdovusvhoszdhvo ousvhosdhvoishdzovhosidzv iosdhviosdzhoivhdoszdhv ioshvoszhvsdzhvosh oisdhvosdzhovhsdozvhodsz osdihvosdzhvoids','1737791834_Screenshot_2024-09-15_210707.png','1737859778_Screenshot_2024-10-12_153011.png',NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-25 15:57:14','2025-01-26 10:57:02'),
(3,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','Ngetes Lagi','aknckancnas invinvisdnvinds','1737939841_Screenshot_2024-11-19_113832.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-27 09:04:02','2025-01-27 09:04:02'),
(4,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','Ngetes Lagi','fkdsnvjkdsnvsd','1737942269_Screenshot_2024-09-10_164916.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-27 09:44:30','2025-01-27 09:44:30'),
(5,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','jncsacna','kjnvjkdsnkvjdsnvkjsd','1737942323_cpanel.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-27 09:45:23','2025-01-27 09:45:23'),
(6,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','knknnkn','uihiudsnvks','1737942392_Screenshot_2024-09-04_234702.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-27 09:46:32','2025-01-27 09:46:32'),
(7,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','final','ksmdkcmsdkcms mmckskcksdmc tes','1737951516_Screenshot_2024-09-10_164916.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-27 12:18:36','2025-01-27 12:18:36');

/*Table structure for table `tb_datamengajar` */

DROP TABLE IF EXISTS `tb_datamengajar`;

CREATE TABLE `tb_datamengajar` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guru_id` bigint(20) unsigned DEFAULT NULL,
  `matapelajaran_id` bigint(20) unsigned DEFAULT NULL,
  `hari` varchar(255) DEFAULT NULL,
  `awalpel` time DEFAULT NULL,
  `akhirpel` time DEFAULT NULL,
  `awalis` time DEFAULT NULL,
  `akhiris` time DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_datamengajar_guru_id_foreign` (`guru_id`),
  KEY `tb_datamengajar_matapelajaran_id_foreign` (`matapelajaran_id`),
  CONSTRAINT `tb_datamengajar_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `tb_guru` (`guru_id`) ON DELETE SET NULL,
  CONSTRAINT `tb_datamengajar_matapelajaran_id_foreign` FOREIGN KEY (`matapelajaran_id`) REFERENCES `tb_matapelajaran` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_datamengajar` */

insert  into `tb_datamengajar`(`id`,`guru_id`,`matapelajaran_id`,`hari`,`awalpel`,`akhirpel`,`awalis`,`akhiris`,`ket`,`created_at`,`updated_at`) values 
(3,1,1,'Senin','12:14:00','22:48:00','12:46:00','22:48:00','gatau','2024-12-22 22:48:10','2024-12-22 22:48:10'),
(4,1,2,'Rabu','08:59:00','12:59:00','00:59:00','00:58:00','gatau','2024-12-22 22:48:43','2024-12-22 22:48:43'),
(5,1,3,'Senin','04:27:00','04:28:00','08:25:00','04:28:00','gatau','2025-01-02 04:25:40','2025-01-02 04:25:40');

/*Table structure for table `tb_ekstra_siswa` */

DROP TABLE IF EXISTS `tb_ekstra_siswa`;

CREATE TABLE `tb_ekstra_siswa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ekstrakulikuler_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_ekstra_siswa_ekstrakulikuler_id_foreign` (`ekstrakulikuler_id`),
  KEY `tb_ekstra_siswa_user_id_foreign` (`user_id`),
  CONSTRAINT `tb_ekstra_siswa_ekstrakulikuler_id_foreign` FOREIGN KEY (`ekstrakulikuler_id`) REFERENCES `tb_ekstrakulikuler` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tb_ekstra_siswa_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_ekstra_siswa` */

/*Table structure for table `tb_ekstrakulikuler` */

DROP TABLE IF EXISTS `tb_ekstrakulikuler`;

CREATE TABLE `tb_ekstrakulikuler` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guru_id` bigint(20) unsigned DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `namaekstra` varchar(255) DEFAULT NULL,
  `kapasitas` int(11) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tahunakademik_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_ekstrakulikuler_guru_id_foreign` (`guru_id`),
  KEY `tb_ekstrakulikuler_tahunakademik_id_foreign` (`tahunakademik_id`),
  CONSTRAINT `tb_ekstrakulikuler_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `tb_guru` (`guru_id`) ON DELETE SET NULL,
  CONSTRAINT `tb_ekstrakulikuler_tahunakademik_id_foreign` FOREIGN KEY (`tahunakademik_id`) REFERENCES `tb_tahunakademik` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_ekstrakulikuler` */

insert  into `tb_ekstrakulikuler`(`id`,`guru_id`,`foto`,`namaekstra`,`kapasitas`,`status`,`ket`,`created_at`,`updated_at`,`tahunakademik_id`) values 
(2,1,'1737365034_image__3_.png','berak',3,'Aktif','gatau','2025-01-04 09:03:18','2025-01-20 17:23:56',1),
(4,1,NULL,'Gatau',2,'Aktif','gatau','2025-01-04 18:35:15','2025-01-04 18:35:15',1),
(5,1,NULL,'tes abc',2,'Aktif','ngetes','2025-01-18 03:48:01','2025-01-18 03:48:01',1),
(6,1,NULL,'kakaka',11,'Aktif','tes','2025-01-18 03:49:11','2025-01-18 03:49:11',6);

/*Table structure for table `tb_guru` */

DROP TABLE IF EXISTS `tb_guru`;

CREATE TABLE `tb_guru` (
  `guru_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `foto` varchar(255) DEFAULT NULL,
  `Nama` varchar(255) DEFAULT NULL,
  `TempatLahir` varchar(255) DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `Agama` enum('Islam','Kristen Protestan','Katolik','Hindu','Buddha','Konghucu') DEFAULT NULL,
  `JenisKelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `StatusPegawai` enum('GT','PNS YDP','GTT','Honorer','PT','PTT') DEFAULT NULL,
  `NipNips` varchar(255) DEFAULT NULL,
  `Nuptk` varchar(255) DEFAULT NULL,
  `Nik` varchar(255) DEFAULT NULL,
  `Npwp` varchar(255) DEFAULT NULL,
  `NomorSertifikatPendidik` varchar(255) DEFAULT NULL,
  `TahunSertifikasi` date DEFAULT NULL,
  `jadwalkenaikangaji` date DEFAULT NULL,
  `PendidikanAkhir` varchar(255) DEFAULT NULL,
  `TahunTamat` date DEFAULT NULL,
  `Jurusan` varchar(255) DEFAULT NULL,
  `TugasMengajar` varchar(255) DEFAULT NULL,
  `TahunPensiun` date DEFAULT NULL,
  `Pangkat` varchar(255) DEFAULT NULL,
  `jadwalkenaikanpangkat` date DEFAULT NULL,
  `Jabatan` varchar(255) DEFAULT NULL,
  `NomorTelephone` varchar(255) DEFAULT NULL,
  `Alamat` text DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`guru_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_guru` */

insert  into `tb_guru`(`guru_id`,`foto`,`Nama`,`TempatLahir`,`TanggalLahir`,`Agama`,`JenisKelamin`,`StatusPegawai`,`NipNips`,`Nuptk`,`Nik`,`Npwp`,`NomorSertifikatPendidik`,`TahunSertifikasi`,`jadwalkenaikangaji`,`PendidikanAkhir`,`TahunTamat`,`Jurusan`,`TugasMengajar`,`TahunPensiun`,`Pangkat`,`jadwalkenaikanpangkat`,`Jabatan`,`NomorTelephone`,`Alamat`,`Email`,`status`,`created_at`,`updated_at`) values 
(1,NULL,'Christopher Edwin Sirait','mataram','2000-12-05','Konghucu','Laki-Laki','PNS YDP','0895632288892','8787','0895632288892','8734432','1212','2024-12-05','2024-12-20','S3','2024-12-20','KOMPUTER','KOMPUTER','2024-12-19','brigadir jendral','2024-12-20','kepala divisi JAV','085739920655','mataram','kris@gmail.com','Aktif','2024-12-20 22:04:07','2025-01-19 13:55:51');

/*Table structure for table `tb_hasil_voting` */

DROP TABLE IF EXISTS `tb_hasil_voting`;

CREATE TABLE `tb_hasil_voting` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `osis_id` bigint(20) unsigned DEFAULT NULL,
  `jumlahsuara` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_hasil_voting_osis_id_foreign` (`osis_id`),
  CONSTRAINT `tb_hasil_voting_osis_id_foreign` FOREIGN KEY (`osis_id`) REFERENCES `tb_osis` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_hasil_voting` */

/*Table structure for table `tb_kelas` */

DROP TABLE IF EXISTS `tb_kelas`;

CREATE TABLE `tb_kelas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guru_id` bigint(20) unsigned DEFAULT NULL,
  `tahunakademik_id` bigint(20) unsigned DEFAULT NULL,
  `kelas` varchar(255) DEFAULT NULL,
  `kapasitas` int(11) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_kelas_guru_id_foreign` (`guru_id`),
  KEY `tb_kelas_tahunakademik_id_foreign` (`tahunakademik_id`),
  CONSTRAINT `tb_kelas_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `tb_guru` (`guru_id`) ON DELETE SET NULL,
  CONSTRAINT `tb_kelas_tahunakademik_id_foreign` FOREIGN KEY (`tahunakademik_id`) REFERENCES `tb_tahunakademik` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_kelas` */

insert  into `tb_kelas`(`id`,`guru_id`,`tahunakademik_id`,`kelas`,`kapasitas`,`status`,`ket`,`created_at`,`updated_at`) values 
(1,1,1,'XIIB',4,'Aktif','gatau','2024-12-21 20:26:27','2025-01-07 14:27:35'),
(3,1,6,'XIIB',22,'Aktif','gatau','2025-01-02 16:13:34','2025-01-07 14:27:48');

/*Table structure for table `tb_kepalasekolah` */

DROP TABLE IF EXISTS `tb_kepalasekolah`;

CREATE TABLE `tb_kepalasekolah` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `header` text DEFAULT NULL,
  `body` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_kepalasekolah_user_id_foreign` (`user_id`),
  CONSTRAINT `tb_kepalasekolah_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_kepalasekolah` */

/*Table structure for table `tb_kurikulum` */

DROP TABLE IF EXISTS `tb_kurikulum`;

CREATE TABLE `tb_kurikulum` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kurikulum` varchar(255) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_kurikulum` */

insert  into `tb_kurikulum`(`id`,`kurikulum`,`status`,`ket`,`created_at`,`updated_at`) values 
(1,'kurikulum mer','Aktif','gatau','2024-12-21 09:36:37','2024-12-21 09:36:37'),
(2,'tes kuri','Aktif','gatau','2024-12-21 18:33:10','2024-12-21 18:33:10');

/*Table structure for table `tb_matapelajaran` */

DROP TABLE IF EXISTS `tb_matapelajaran`;

CREATE TABLE `tb_matapelajaran` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `matapelajaran` varchar(255) DEFAULT NULL,
  `kkm` varchar(255) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_matapelajaran` */

insert  into `tb_matapelajaran`(`id`,`matapelajaran`,`kkm`,`status`,`ket`,`created_at`,`updated_at`) values 
(1,'Bahasa Indonesia','75','Aktif','gatau','2024-12-22 09:43:09','2024-12-22 09:43:09'),
(2,'matematika','75','Aktif','gatau','2024-12-22 09:43:22','2024-12-22 09:43:22'),
(3,'Aljabar','96','Aktif','gatau','2024-12-22 09:43:35','2024-12-22 09:43:35');

/*Table structure for table `tb_organisasi` */

DROP TABLE IF EXISTS `tb_organisasi`;

CREATE TABLE `tb_organisasi` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `guru_id` bigint(20) unsigned DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `namaorganisasi` varchar(255) DEFAULT NULL,
  `kapasitas` int(11) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tahunakademik_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_organisasi_guru_id_foreign` (`guru_id`),
  KEY `tb_organisasi_tahunakademik_id_foreign` (`tahunakademik_id`),
  CONSTRAINT `tb_organisasi_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `tb_guru` (`guru_id`) ON DELETE SET NULL,
  CONSTRAINT `tb_organisasi_tahunakademik_id_foreign` FOREIGN KEY (`tahunakademik_id`) REFERENCES `tb_tahunakademik` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_organisasi` */

insert  into `tb_organisasi`(`id`,`guru_id`,`foto`,`namaorganisasi`,`kapasitas`,`status`,`ket`,`created_at`,`updated_at`,`tahunakademik_id`) values 
(1,1,NULL,'tesaa',22,'Aktif','gatau','2024-12-21 22:07:27','2024-12-21 22:07:27',1),
(2,1,NULL,'tesaa',2,'Aktif','gatau',NULL,'2025-01-19 12:06:31',1);

/*Table structure for table `tb_organisasi_siswa` */

DROP TABLE IF EXISTS `tb_organisasi_siswa`;

CREATE TABLE `tb_organisasi_siswa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organisasi_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_organisasi_siswa_organisasi_id_foreign` (`organisasi_id`),
  KEY `tb_organisasi_siswa_user_id_foreign` (`user_id`),
  CONSTRAINT `tb_organisasi_siswa_organisasi_id_foreign` FOREIGN KEY (`organisasi_id`) REFERENCES `tb_organisasi` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tb_organisasi_siswa_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_organisasi_siswa` */

/*Table structure for table `tb_osis` */

DROP TABLE IF EXISTS `tb_osis`;

CREATE TABLE `tb_osis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned DEFAULT NULL,
  `visi` varchar(255) DEFAULT NULL,
  `misi` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_osis_siswa_id_foreign` (`siswa_id`),
  CONSTRAINT `tb_osis_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `tb_siswa` (`siswa_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_osis` */

insert  into `tb_osis`(`id`,`siswa_id`,`visi`,`misi`,`created_at`,`updated_at`) values 
(1,1,'bgndgn','dgndgndg','2024-12-21 18:22:43','2024-12-21 18:22:43'),
(3,3,'gatau','gatay','2025-01-17 19:06:18','2025-01-17 19:06:18'),
(4,1,'gatau','gatay','2025-01-17 21:20:30','2025-01-17 21:20:30');

/*Table structure for table `tb_pembayaran` */

DROP TABLE IF EXISTS `tb_pembayaran`;

CREATE TABLE `tb_pembayaran` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('Menunggu Pembayaran','Dalam Antrian','Lunas') DEFAULT NULL,
  `tanggalbukti` datetime DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_pembayaran_siswa_id_foreign` (`siswa_id`),
  CONSTRAINT `tb_pembayaran_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `tb_siswa` (`siswa_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_pembayaran` */

insert  into `tb_pembayaran`(`id`,`siswa_id`,`status`,`tanggalbukti`,`foto`,`created_at`,`updated_at`) values 
(1,6,'Dalam Antrian','2025-01-23 10:14:22','1737598462_photo_2025-01-22_15-27-53.jpg','2025-01-22 11:32:34','2025-01-23 10:14:22');

/*Table structure for table `tb_pengaturan_kelas` */

DROP TABLE IF EXISTS `tb_pengaturan_kelas`;

CREATE TABLE `tb_pengaturan_kelas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kelas_id` bigint(20) unsigned DEFAULT NULL,
  `tahunakademik_id` bigint(20) unsigned DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_pengaturan_kelas_kelas_id_foreign` (`kelas_id`),
  KEY `tb_pengaturan_kelas_tahunakademik_id_foreign` (`tahunakademik_id`),
  CONSTRAINT `tb_pengaturan_kelas_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `tb_kelas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tb_pengaturan_kelas_tahunakademik_id_foreign` FOREIGN KEY (`tahunakademik_id`) REFERENCES `tb_tahunakademik` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_pengaturan_kelas` */

insert  into `tb_pengaturan_kelas`(`id`,`kelas_id`,`tahunakademik_id`,`ket`,`status`,`created_at`,`updated_at`) values 
(1,1,1,'gatau','Tidak Aktif','2024-12-24 17:47:15','2025-01-20 17:45:56'),
(3,3,6,NULL,NULL,'2024-12-28 17:39:29','2024-12-28 17:39:29');

/*Table structure for table `tb_pengaturankelas_siswa` */

DROP TABLE IF EXISTS `tb_pengaturankelas_siswa`;

CREATE TABLE `tb_pengaturankelas_siswa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned DEFAULT NULL,
  `pengaturankelas_id` bigint(20) unsigned DEFAULT NULL,
  `datamengajar_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_pengaturankelas_siswa_siswa_id_foreign` (`siswa_id`),
  KEY `tb_pengaturankelas_siswa_pengaturankelas_id_foreign` (`pengaturankelas_id`),
  KEY `tb_pengaturankelas_siswa_datamengajar_id_foreign` (`datamengajar_id`),
  CONSTRAINT `tb_pengaturankelas_siswa_datamengajar_id_foreign` FOREIGN KEY (`datamengajar_id`) REFERENCES `tb_datamengajar` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tb_pengaturankelas_siswa_pengaturankelas_id_foreign` FOREIGN KEY (`pengaturankelas_id`) REFERENCES `tb_pengaturan_kelas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tb_pengaturankelas_siswa_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `tb_siswa` (`siswa_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_pengaturankelas_siswa` */

insert  into `tb_pengaturankelas_siswa`(`id`,`siswa_id`,`pengaturankelas_id`,`datamengajar_id`,`created_at`,`updated_at`) values 
(92,1,1,3,NULL,NULL),
(93,1,1,4,NULL,NULL),
(94,1,1,5,NULL,NULL),
(98,1,3,3,NULL,NULL),
(99,1,3,4,NULL,NULL),
(100,1,3,5,NULL,NULL),
(101,2,3,3,NULL,NULL),
(102,2,3,4,NULL,NULL),
(103,2,3,5,NULL,NULL);

/*Table structure for table `tb_pengumuman` */

DROP TABLE IF EXISTS `tb_pengumuman`;

CREATE TABLE `tb_pengumuman` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pengumuman` varchar(255) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_pengumuman` */

insert  into `tb_pengumuman`(`id`,`pengumuman`,`deskripsi`,`created_at`,`updated_at`) values 
(1,'tes data.xlsx','Admin','2024-12-20 22:41:11','2024-12-20 22:41:11'),
(2,'Lembar Pengesahan TA_1905551166_Christopher Edwin Sirait (5).pdf','Admin','2025-01-19 13:56:17','2025-01-19 13:56:17');

/*Table structure for table `tb_profile` */

DROP TABLE IF EXISTS `tb_profile`;

CREATE TABLE `tb_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `header` varchar(255) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `gambar1` varchar(255) DEFAULT NULL,
  `gambar2` varchar(255) DEFAULT NULL,
  `gambar3` varchar(255) DEFAULT NULL,
  `gambar4` varchar(255) DEFAULT NULL,
  `gambar5` varchar(255) DEFAULT NULL,
  `gambar6` varchar(255) DEFAULT NULL,
  `gambar7` varchar(255) DEFAULT NULL,
  `gambar8` varchar(255) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_profile_user_id_foreign` (`user_id`),
  CONSTRAINT `tb_profile_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_profile` */

insert  into `tb_profile`(`id`,`user_id`,`header`,`body`,`gambar1`,`gambar2`,`gambar3`,`gambar4`,`gambar5`,`gambar6`,`gambar7`,`gambar8`,`status`,`created_at`,`updated_at`) values 
(1,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','Sambutan Kepala Sekolah','Salam Sejahtera...  SMAK Kesuma Mataram adalah singkatan dari Sekolah Menengah Atas Katolik Kesuma. Kata Kesuma merupakan singkatan dari Kecerdasan Suluh Masyarakat, yang berarti bahwa sekolah ini berpartisipasi aktif dalam usaha mencerdaskan generasi penerus bangsa demi kemajuan pembangunan bangsa ini. Melalui pendidikan yang berkualitas, SMAK Kesuma berusaha membentuk siswa-siswi yang tidak hanya cerdas secara akademis, tetapi juga memiliki karakter yang kuat dan berbudi pekerti luhur.  SMAK Kesuma mulai dirintis pada tahun 1965 oleh tim pendiri yang dipimpin oleh Uskup Bali-Lombok, Mgr. Dr. Paulus Sani, SVD, dan diresmikan pada tanggal 5 Agustus 1965 oleh Bapak Roeslan Tjakraningrat yang saat itu menjabat sebagai Gubernur Daerah Tingkat I Provinsi Nusa Tenggara Barat. Inisiatif ini muncul dari kebutuhan akan pendidikan menengah atas yang bermutu di wilayah tersebut, yang mampu mencetak generasi muda yang siap berkontribusi positif bagi masyarakat dan bangsa.  Pada awal berdirinya, SMAK Kesuma Mataram hanya memiliki tiga kelas dengan jumlah 90 siswa. Mereka didampingi oleh lima guru tetap dan tujuh guru tidak tetap, yang pengelolaannya berada di bawah Keuskupan Bali-Lombok dengan pelaksana pastor paroki St. Maria Imaculata Mataram. Seiring waktu, pengelolaan sekolah ini beralih ke Yayasan Swastiastu, yang kini telah berganti nama menjadi Yayasan Insan Mandiri Denpasar dan berpusat di Denpasar, Bali. Yayasan ini terus berkomitmen untuk memberikan pendidikan berkualitas yang sesuai dengan perkembangan zaman.  Lokasi sekolah pada awalnya berada di Jalan Beo, Cakranegara. Namun, dengan meningkatnya jumlah siswa dan kebutuhan akan fasilitas yang lebih memadai, SMAK Kesuma Mataram kemudian dipindahkan ke lokasi yang lebih luas di Jalan Pejanggik No. 110, Mataram. Letaknya yang strategis di dekat pusat perbelanjaan kota Mataram memberikan dampak positif bagi warga sekolah sebagai wahana edukasi. Di satu sisi, hal ini sangat memudahkan bagi segenap warga sekolah untuk mencapai lokasi sekolah dengan akses transportasi yang terjangkau.  Berdiri di tengah kota, SMAK Kesuma telah berkembang menjadi sekolah berakreditasi A dan memperoleh predikat sebagai Rintisan Sekolah Standar Nasional (RSSN) atau Sekolah Kategori Mandiri (SKM). Sekolah ini telah menerapkan kurikulum baru yakni Kurikulum Merdeka. Kurikulum ini menekankan pada pembelajaran yang lebih fleksibel dan berpusat pada siswa, serta memberikan ruang bagi pengembangan kreativitas dan inovasi.  Selain prestasi akademis, SMAK Kesuma juga aktif dalam berbagai kegiatan ekstrakurikuler yang bertujuan untuk mengembangkan bakat dan minat siswa. Kegiatan-kegiatan ini meliputi olahraga, seni, dan berbagai organisasi siswa yang memberikan kesempatan bagi siswa untuk belajar kepemimpinan dan kerjasama tim. Sekolah ini juga sering mengadakan kegiatan sosial dan kemasyarakatan yang mengajarkan siswa tentang pentingnya berkontribusi kepada masyarakat.  Dengan segala fasilitas dan program yang dimilikinya, SMAK Kesuma Mataram terus berupaya untuk menjadi lembaga pendidikan yang unggul dan terpercaya. Visi dan misi sekolah ini selalu mengarah pada pencapaian pendidikan yang holistik, dimana siswa tidak hanya siap menghadapi tantangan akademis, tetapi juga siap berperan aktif dalam masyarakat dengan nilai-nilai luhur yang mereka peroleh selama bersekolah di SMAK Kesuma.','1737948468_Screenshot_2024-10-12_153011.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aktif','2025-01-27 11:27:48','2025-01-27 11:44:14');

/*Table structure for table `tb_siswa` */

DROP TABLE IF EXISTS `tb_siswa`;

CREATE TABLE `tb_siswa` (
  `siswa_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `foto` varchar(255) DEFAULT NULL,
  `NamaLengkap` varchar(255) DEFAULT NULL,
  `NomorInduk` varchar(255) DEFAULT NULL,
  `NamaPanggilan` varchar(255) DEFAULT NULL,
  `JenisKelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `NISN` varchar(255) DEFAULT NULL,
  `TempatLahir` varchar(255) DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `Agama` enum('Katolik','Kristen Protestan','Hindu','Buddha','Islam','Konghucu') DEFAULT NULL,
  `Alamat` text DEFAULT NULL,
  `RT` varchar(255) DEFAULT NULL,
  `RW` varchar(255) DEFAULT NULL,
  `Kelurahan` varchar(255) DEFAULT NULL,
  `Kecamatan` varchar(255) DEFAULT NULL,
  `KabKota` varchar(255) DEFAULT NULL,
  `Provinsi` varchar(255) DEFAULT NULL,
  `KodePos` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `NomorTelephone` varchar(255) DEFAULT NULL,
  `Kewarganegaraan` varchar(255) DEFAULT NULL,
  `NIK` varchar(255) DEFAULT NULL,
  `GolDarah` varchar(255) DEFAULT NULL,
  `TinggalDengan` varchar(255) DEFAULT NULL,
  `StatusSiswa` enum('Lengkap','Yatim','Piatu','Yatim Piatu') DEFAULT NULL,
  `AnakKe` enum('1','2','3','4','5') DEFAULT NULL,
  `SaudaraKandung` enum('1','2','3','4','5') DEFAULT NULL,
  `SaudaraTiri` enum('1','2','3','4','5') DEFAULT NULL,
  `Tinggicm` int(11) DEFAULT NULL,
  `Beratkg` int(11) DEFAULT NULL,
  `RiwayatPenyakit` text DEFAULT NULL,
  `AsalSD` varchar(255) DEFAULT NULL,
  `AlamatSD` text DEFAULT NULL,
  `NPSNSD` varchar(255) DEFAULT NULL,
  `KabKotaSD` varchar(255) DEFAULT NULL,
  `ProvinsiSD` varchar(255) DEFAULT NULL,
  `NoIjasah` varchar(255) DEFAULT NULL,
  `DiterimaTanggal` date DEFAULT NULL,
  `DiterimaDiKelas` enum('X','XI','XII') DEFAULT NULL,
  `DiterimaSemester` enum('Ganjil','Genap') DEFAULT NULL,
  `MutasiAsalSMP` varchar(255) DEFAULT NULL,
  `AlasanPindah` text DEFAULT NULL,
  `TglIjasahSD` date DEFAULT NULL,
  `NamaOrangTuaPadaIjasah` varchar(255) DEFAULT NULL,
  `NamaAyah` varchar(255) DEFAULT NULL,
  `TahunLahirAyah` int(11) DEFAULT NULL,
  `AlamatAyah` text DEFAULT NULL,
  `NomorTelephoneAyah` varchar(255) DEFAULT NULL,
  `AgamaAyah` varchar(255) DEFAULT NULL,
  `PendidikanTerakhirAyah` varchar(255) DEFAULT NULL,
  `PekerjaanAyah` varchar(255) DEFAULT NULL,
  `PenghasilanAyah` varchar(255) DEFAULT NULL,
  `NamaIbu` varchar(255) DEFAULT NULL,
  `TahunLahirIbu` int(11) DEFAULT NULL,
  `AlamatIbu` text DEFAULT NULL,
  `NomorTelephoneIbu` varchar(255) DEFAULT NULL,
  `AgamaIbu` varchar(255) DEFAULT NULL,
  `PendidikanTerakhirIbu` varchar(255) DEFAULT NULL,
  `PekerjaanIbu` varchar(255) DEFAULT NULL,
  `PenghasilanIbu` varchar(255) DEFAULT NULL,
  `NamaWali` varchar(255) DEFAULT NULL,
  `TahunLahirWali` int(11) DEFAULT NULL,
  `AlamatWali` text DEFAULT NULL,
  `NomorTelephoneWali` varchar(255) DEFAULT NULL,
  `AgamaWali` varchar(255) DEFAULT NULL,
  `PendidikanTerakhirWali` varchar(255) DEFAULT NULL,
  `PekerjaanWali` varchar(255) DEFAULT NULL,
  `WaliPenghasilan` varchar(255) DEFAULT NULL,
  `StatusHubunganWali` varchar(255) DEFAULT NULL,
  `MenerimaBeasiswaDari` text DEFAULT NULL,
  `TahunMeninggalkanSekolah` int(11) DEFAULT NULL,
  `AlasanSebab` text DEFAULT NULL,
  `TamatBelajarTahun` date DEFAULT NULL,
  `InformasiLain` text DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif','Lulus','Alumni') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`siswa_id`),
  UNIQUE KEY `tb_siswa_nomorinduk_unique` (`NomorInduk`),
  UNIQUE KEY `tb_siswa_nik_unique` (`NIK`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_siswa` */

insert  into `tb_siswa`(`siswa_id`,`foto`,`NamaLengkap`,`NomorInduk`,`NamaPanggilan`,`JenisKelamin`,`NISN`,`TempatLahir`,`TanggalLahir`,`Agama`,`Alamat`,`RT`,`RW`,`Kelurahan`,`Kecamatan`,`KabKota`,`Provinsi`,`KodePos`,`Email`,`NomorTelephone`,`Kewarganegaraan`,`NIK`,`GolDarah`,`TinggalDengan`,`StatusSiswa`,`AnakKe`,`SaudaraKandung`,`SaudaraTiri`,`Tinggicm`,`Beratkg`,`RiwayatPenyakit`,`AsalSD`,`AlamatSD`,`NPSNSD`,`KabKotaSD`,`ProvinsiSD`,`NoIjasah`,`DiterimaTanggal`,`DiterimaDiKelas`,`DiterimaSemester`,`MutasiAsalSMP`,`AlasanPindah`,`TglIjasahSD`,`NamaOrangTuaPadaIjasah`,`NamaAyah`,`TahunLahirAyah`,`AlamatAyah`,`NomorTelephoneAyah`,`AgamaAyah`,`PendidikanTerakhirAyah`,`PekerjaanAyah`,`PenghasilanAyah`,`NamaIbu`,`TahunLahirIbu`,`AlamatIbu`,`NomorTelephoneIbu`,`AgamaIbu`,`PendidikanTerakhirIbu`,`PekerjaanIbu`,`PenghasilanIbu`,`NamaWali`,`TahunLahirWali`,`AlamatWali`,`NomorTelephoneWali`,`AgamaWali`,`PendidikanTerakhirWali`,`PekerjaanWali`,`WaliPenghasilan`,`StatusHubunganWali`,`MenerimaBeasiswaDari`,`TahunMeninggalkanSekolah`,`AlasanSebab`,`TamatBelajarTahun`,`InformasiLain`,`status`,`created_at`,`updated_at`) values 
(1,'1734705502_Screenshot_2024-09-04_234702.png','Kevin vhristopan','0000','kevin','Laki-Laki','0000','mararam','2024-12-20','Hindu','gatau','03','03','mamball','mabalan','mataram','ntb','9465','drummerboy694@gmail.com','00000','italia','0234234234','B-','istri orang','Lengkap','5','5','5',201,99,'kanker','sd 1 italia','italia','00000','italia','italia','23748463739','2024-02-20','X','Ganjil','spanyol','terlalu pinter','2024-12-20','vadel','wiliam',2009,'selagalas','0877655443','Konghucu','ngentot','ngemis','jadi gigolo','eva elvie',1998,'france','089765432431','Islam','sd','LC','karoke','gatau',2000,'portugal','0234234n','Buddha','smp','bandae narkotika','ngedar barang','wali hidup','oxford',2000,'udah pinter','2024-12-25','tra ada','Aktif','2025-01-21 01:36:21','2025-01-17 18:14:38'),
(2,NULL,'kevin musabakoh tilawatil quran','111111111','telor','Laki-Laki','2222222','Mataram','2000-10-12','Islam','mars','10','21','kelod','abian kapas','sumba','ntt','3244','drummerboy694@gmail.com','0874560921','wakanda','0231456','A+','orang','Yatim Piatu','1','1','1',180,100,'kanker','sumba','meduri','99999','lingsar','ntt','0987765432','2021-12-03','X','Genap','papua','terlalu bodoh','2014-02-03','muhamad','muhamad',1945,'rembige','0897654321','Katolik','bandung','ngemis','1 juta','baiq',1920,'griya','5','Islam','gatau','gatau','gatau','gatau',2000,'gatau','0234234n','Islam','lingsar','lingsar','gatau','lingsar','gatau',2000,'gatau','2000-12-12','gatau','Aktif','2025-01-21 01:36:27','2024-12-26 20:22:49'),
(3,NULL,'ngetes',NULL,'kevin','Laki-Laki',NULL,'mataram','2000-12-12','Katolik','meduri',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0895632288892',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0895632288892',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tidak Aktif','2025-01-15 20:16:33','2025-01-15 20:16:33'),
(4,NULL,'ahmad sultoni zikri',NULL,'sulton','Laki-Laki',NULL,'mataram','2009-04-09','Islam','jln penjanggik',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0895632288892',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'02342432',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tidak Aktif','2025-01-21 15:30:12','2025-01-21 15:30:12'),
(5,NULL,'basongba',NULL,'snvjsdvdkkv','Laki-Laki',NULL,'mataram','2000-12-12','Katolik','meduri',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'9349234888888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tidak Aktif','2025-01-22 07:51:18','2025-01-22 07:51:18'),
(6,'1737612194_Screenshot_2024-09-04_234702.png','ngetes akun bos',NULL,'snvjsdvdkkv','Laki-Laki',NULL,'mataram','2000-12-12','Katolik','meduri',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'9349234888888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0895632288892',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tidak Aktif','2025-01-22 11:32:33','2025-01-23 14:03:14');

/*Table structure for table `tb_siswaarsip` */

DROP TABLE IF EXISTS `tb_siswaarsip`;

CREATE TABLE `tb_siswaarsip` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `NamaLengkap` varchar(255) DEFAULT NULL,
  `NomorInduk` varchar(255) DEFAULT NULL,
  `NamaPanggilan` varchar(255) DEFAULT NULL,
  `JenisKelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `NISN` varchar(255) DEFAULT NULL,
  `TempatLahir` varchar(255) DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `Agama` enum('Katolik','Kristen Protestan','Hindu','Buddha','Islam','Konghucu') DEFAULT NULL,
  `Alamat` text DEFAULT NULL,
  `RT` varchar(255) DEFAULT NULL,
  `RW` varchar(255) DEFAULT NULL,
  `Kelurahan` varchar(255) DEFAULT NULL,
  `Kecamatan` varchar(255) DEFAULT NULL,
  `KabKota` varchar(255) DEFAULT NULL,
  `Provinsi` varchar(255) DEFAULT NULL,
  `KodePos` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `NomorTelephone` varchar(255) DEFAULT NULL,
  `Kewarganegaraan` varchar(255) DEFAULT NULL,
  `NIK` varchar(255) DEFAULT NULL,
  `GolDarah` varchar(255) DEFAULT NULL,
  `TinggalDengan` varchar(255) DEFAULT NULL,
  `StatusSiswa` enum('Lengkap','Yatim','Piatu','Yatim Piatu') DEFAULT NULL,
  `AnakKe` enum('1','2','3','4','5') DEFAULT NULL,
  `SaudaraKandung` enum('1','2','3','4','5') DEFAULT NULL,
  `SaudaraTiri` enum('1','2','3','4','5') DEFAULT NULL,
  `Tinggicm` int(11) DEFAULT NULL,
  `Beratkg` int(11) DEFAULT NULL,
  `RiwayatPenyakit` text DEFAULT NULL,
  `AsalSD` varchar(255) DEFAULT NULL,
  `AlamatSD` text DEFAULT NULL,
  `NPSNSD` varchar(255) DEFAULT NULL,
  `KabKotaSD` varchar(255) DEFAULT NULL,
  `ProvinsiSD` varchar(255) DEFAULT NULL,
  `NoIjasah` varchar(255) DEFAULT NULL,
  `DiterimaTanggal` date DEFAULT NULL,
  `DiterimaDiKelas` enum('X','XI','XII') DEFAULT NULL,
  `DiterimaSemester` enum('Ganjil','Genap') DEFAULT NULL,
  `MutasiAsalSMP` varchar(255) DEFAULT NULL,
  `AlasanPindah` text DEFAULT NULL,
  `TglIjasahSD` date DEFAULT NULL,
  `NamaOrangTuaPadaIjasah` varchar(255) DEFAULT NULL,
  `NamaAyah` varchar(255) DEFAULT NULL,
  `TahunLahirAyah` int(11) DEFAULT NULL,
  `AlamatAyah` text DEFAULT NULL,
  `NomorTelephoneAyah` varchar(255) DEFAULT NULL,
  `AgamaAyah` varchar(255) DEFAULT NULL,
  `PendidikanTerakhirAyah` varchar(255) DEFAULT NULL,
  `PekerjaanAyah` varchar(255) DEFAULT NULL,
  `PenghasilanAyah` varchar(255) DEFAULT NULL,
  `NamaIbu` varchar(255) DEFAULT NULL,
  `TahunLahirIbu` int(11) DEFAULT NULL,
  `AlamatIbu` text DEFAULT NULL,
  `NomorTelephoneIbu` varchar(255) DEFAULT NULL,
  `AgamaIbu` varchar(255) DEFAULT NULL,
  `PendidikanTerakhirIbu` varchar(255) DEFAULT NULL,
  `PekerjaanIbu` varchar(255) DEFAULT NULL,
  `PenghasilanIbu` varchar(255) DEFAULT NULL,
  `NamaWali` varchar(255) DEFAULT NULL,
  `TahunLahirWali` int(11) DEFAULT NULL,
  `AlamatWali` text DEFAULT NULL,
  `NomorTelephoneWali` varchar(255) DEFAULT NULL,
  `AgamaWali` varchar(255) DEFAULT NULL,
  `PendidikanTerakhirWali` varchar(255) DEFAULT NULL,
  `PekerjaanWali` varchar(255) DEFAULT NULL,
  `WaliPenghasilan` varchar(255) DEFAULT NULL,
  `StatusHubunganWali` varchar(255) DEFAULT NULL,
  `MenerimaBeasiswaDari` text DEFAULT NULL,
  `TahunMeninggalkanSekolah` int(11) DEFAULT NULL,
  `AlasanSebab` text DEFAULT NULL,
  `InformasiLain` text DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif','Lulus','Alumni') DEFAULT NULL,
  `TahunDaftar` date DEFAULT NULL,
  `TamatBelajarTahun` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tb_siswaarsip_namalengkap_unique` (`NamaLengkap`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_siswaarsip` */

insert  into `tb_siswaarsip`(`id`,`NamaLengkap`,`NomorInduk`,`NamaPanggilan`,`JenisKelamin`,`NISN`,`TempatLahir`,`TanggalLahir`,`Agama`,`Alamat`,`RT`,`RW`,`Kelurahan`,`Kecamatan`,`KabKota`,`Provinsi`,`KodePos`,`Email`,`NomorTelephone`,`Kewarganegaraan`,`NIK`,`GolDarah`,`TinggalDengan`,`StatusSiswa`,`AnakKe`,`SaudaraKandung`,`SaudaraTiri`,`Tinggicm`,`Beratkg`,`RiwayatPenyakit`,`AsalSD`,`AlamatSD`,`NPSNSD`,`KabKotaSD`,`ProvinsiSD`,`NoIjasah`,`DiterimaTanggal`,`DiterimaDiKelas`,`DiterimaSemester`,`MutasiAsalSMP`,`AlasanPindah`,`TglIjasahSD`,`NamaOrangTuaPadaIjasah`,`NamaAyah`,`TahunLahirAyah`,`AlamatAyah`,`NomorTelephoneAyah`,`AgamaAyah`,`PendidikanTerakhirAyah`,`PekerjaanAyah`,`PenghasilanAyah`,`NamaIbu`,`TahunLahirIbu`,`AlamatIbu`,`NomorTelephoneIbu`,`AgamaIbu`,`PendidikanTerakhirIbu`,`PekerjaanIbu`,`PenghasilanIbu`,`NamaWali`,`TahunLahirWali`,`AlamatWali`,`NomorTelephoneWali`,`AgamaWali`,`PendidikanTerakhirWali`,`PekerjaanWali`,`WaliPenghasilan`,`StatusHubunganWali`,`MenerimaBeasiswaDari`,`TahunMeninggalkanSekolah`,`AlasanSebab`,`InformasiLain`,`status`,`TahunDaftar`,`TamatBelajarTahun`) values 
(1,'muhammad jeffry','234234','snvjsdvdkkv','Laki-Laki','0','mataram','2024-12-17','Islam','cmksjcksdmc','5','5','gatau','selaparang','rembige','ntb','83124','drummerboy694@gmail.com','895632288892','Indonesia','234234234','A+','gatau','Yatim','2','2','2',175,157,'gatau','lingsar','lingsar','0','lingsar','lingsar','2343242','2000-12-12','X','Ganjil','gatau','gatau','2000-12-12','gatau','kevin',2000,'rembige','895632288892','Islam','ngentot','ngntot','lingsar','kusuma',2000,'griya','896532288892','Islam','gatau','gatau','lingsar','gatau',2000,'gatau','234234','Islam','lingsar','lingsar','lingsar','lingsar','gatau',2000,'gatau','gatau','Alumni','2024-12-17','2024-12-18');

/*Table structure for table `tb_tahunakademik` */

DROP TABLE IF EXISTS `tb_tahunakademik`;

CREATE TABLE `tb_tahunakademik` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kurikulum_id` bigint(20) unsigned DEFAULT NULL,
  `tahunakademik` int(11) DEFAULT NULL,
  `semester` enum('Ganjil','Genap') DEFAULT NULL,
  `tanggalmulai` date DEFAULT NULL,
  `tanggalakhir` date DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_tahunakademik_kurikulum_id_foreign` (`kurikulum_id`),
  CONSTRAINT `tb_tahunakademik_kurikulum_id_foreign` FOREIGN KEY (`kurikulum_id`) REFERENCES `tb_kurikulum` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_tahunakademik` */

insert  into `tb_tahunakademik`(`id`,`kurikulum_id`,`tahunakademik`,`semester`,`tanggalmulai`,`tanggalakhir`,`status`,`ket`,`created_at`,`updated_at`) values 
(1,1,2000,'Genap','2000-12-12','2000-12-12','Aktif','gatau','2024-12-21 15:02:04','2025-01-02 04:53:58'),
(6,1,2002,'Genap','2000-12-12','2000-12-12','Aktif','gatau','2024-12-28 02:10:54','2024-12-28 02:10:54');

/*Table structure for table `tb_tombol` */

DROP TABLE IF EXISTS `tb_tombol`;

CREATE TABLE `tb_tombol` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `ket` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_tombol` */

insert  into `tb_tombol`(`id`,`url`,`start_date`,`end_date`,`ket`,`created_at`,`updated_at`) values 
(1,'Voting','2024-12-19 22:06:00','2025-12-20 22:05:00','-','2024-12-20 22:05:56','2024-12-20 22:05:56'),
(2,'Ppdb','2024-12-19 22:06:00','2025-01-22 22:06:00','-','2024-12-20 22:06:20','2025-01-21 14:48:27'),
(3,'Ekstra-ku','2025-01-04 15:34:00','2025-01-20 22:47:00','gatau','2024-12-28 15:34:23','2025-01-18 03:49:34'),
(4,'Organisasi-ku','2025-01-04 15:39:00','2025-06-27 15:39:00','-','2025-01-04 15:39:50','2025-01-04 15:39:50'),
(5,'DatakuSU','2025-01-15 17:17:00','2025-01-16 17:17:00','-','2025-01-17 17:17:54','2025-01-17 17:25:55'),
(6,'DatakuKepalaSekolah','2025-01-17 20:18:00','2025-01-18 17:18:00','-','2025-01-17 17:18:25','2025-01-17 17:18:25'),
(7,'DatakuAdmin','2025-01-08 17:18:00','2025-01-10 17:18:00','-','2025-01-17 17:18:52','2025-01-17 17:18:52'),
(8,'DatakuKurikulum','2025-01-17 17:19:00','2025-01-18 17:19:00','gatau','2025-01-17 17:19:17','2025-01-17 17:19:17'),
(9,'DatakuGuru','2025-01-17 17:23:00','2025-01-18 17:23:00','gatau','2025-01-17 17:23:13','2025-01-17 17:23:13'),
(10,'DatakuSiswa','2025-01-17 17:23:00','2025-02-01 17:23:00','gatau','2025-01-17 17:23:43','2025-01-17 17:23:43');

/*Table structure for table `tb_voting` */

DROP TABLE IF EXISTS `tb_voting`;

CREATE TABLE `tb_voting` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `osis_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_voting_user_id_foreign` (`user_id`),
  KEY `tb_voting_osis_id_foreign` (`osis_id`),
  CONSTRAINT `tb_voting_osis_id_foreign` FOREIGN KEY (`osis_id`) REFERENCES `tb_osis` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tb_voting_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_voting` */

/*Table structure for table `tb_youtube` */

DROP TABLE IF EXISTS `tb_youtube`;

CREATE TABLE `tb_youtube` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tb_youtube_user_id_foreign` (`user_id`),
  CONSTRAINT `tb_youtube_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tb_youtube` */

insert  into `tb_youtube`(`id`,`user_id`,`url`,`status`,`created_at`,`updated_at`) values 
(1,'4c9d2813-c56a-4c19-a2c5-1350faeb3613','https://www.youtube.com/embed/Cfv19SQd11w?si=aIAdoGhU6hzQrupl','Aktif','2025-01-25 10:21:23','2025-01-25 10:46:21');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `guru_id` bigint(20) unsigned DEFAULT NULL,
  `siswa_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `hakakses` enum('SU','Admin','Guru','Siswa','Kurikulum','NonSiswa','KepalaSekolah') DEFAULT NULL,
  `Role` set('SU','Admin','Guru','Kurikulum','KepalaSekolah','Siswa','NonSiswa') DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_guru_id_foreign` (`guru_id`),
  KEY `users_siswa_id_foreign` (`siswa_id`),
  CONSTRAINT `users_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `tb_guru` (`guru_id`) ON DELETE CASCADE,
  CONSTRAINT `users_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `tb_siswa` (`siswa_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`guru_id`,`siswa_id`,`username`,`password`,`hakakses`,`Role`,`remember_token`,`created_at`,`updated_at`) values 
('00016be6-c2aa-47d1-b264-a04b9b558043',NULL,NULL,'1000043','$2y$10$4BIfBRes4QEfpQgEV537aOPFerOJ5M13Q.HSM5xpszJg8t8/Z9ZSW','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('04dfc8d9-e7ce-40d1-9c19-1d53cb913b51',NULL,NULL,'1000000','$2y$10$5XwUzk8EVO1TgzJSnhIsw.W0wiOKHDz9UHNzmaO3akXoBxDkCkgqO','Admin','Admin',NULL,'2024-12-20 21:48:47','2024-12-20 21:48:47'),
('06a8141f-fe4a-42ec-93d4-06aca5db3ec5',NULL,NULL,'1000049','$2y$10$.XaUSfMoHXMtARsAmLFhP.liFCKeA2AJJAz9EhSmrZH93LutfzHIO','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('0dc075cf-9768-43ba-b1a9-db901d902175',NULL,NULL,'1000025','$2y$10$Hu.Mw3H1D5/OPscouBYp0.lQdbBVkTyeYhjggckXR1jsggGRlbLP2','Guru',NULL,NULL,'2024-12-20 21:48:53','2024-12-20 21:48:53'),
('112f3082-96a4-4da5-ba00-1033907e40cc',NULL,NULL,'2000007','$2y$10$leadw2HrFc3S6gch0YXq3uLWMSAtDlBvuznWME3ILqHkA.wSXKlDG','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('14527c02-d6f0-4ffa-8262-8a25b6780ecd',NULL,NULL,'1000038','$2y$10$wGrpXkJNjm9a2BBtSElWPOEcXF7gPkQnwc7mJsxoTJ4.pRynFfDTO','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('1905cc39-2153-4a9c-b9fd-ed04da83da0a',NULL,NULL,'1000010','$2y$10$MPxih2LZIher3nQ91/XGou42N.VNjlqCIEkWaOc2WfSiwi9APS5J.','Guru',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('191decaf-64d5-4f1c-bd37-c6ef055f952a',NULL,NULL,'1000023','$2y$10$joJz/g.0Sj1DOSWoAEExWe3Wj6dhvSiSdMY1KZGo0sLCqDvfP/1cO','Guru',NULL,NULL,'2024-12-20 21:48:53','2024-12-20 21:48:53'),
('1994517b-e2cf-425c-b0a2-726055668403',NULL,NULL,'1000052','$2y$10$JdmzUllGu9SECQL8.9AMcOseRQeDjG1JtaL5iwO2EU6XHT36KtXcy','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('1cc111a2-9093-4853-8454-2396441ba6a0',NULL,NULL,'2000002','$2y$10$5Ta4R7.Rmrt24IM88vifT.aCq/JNVQeQg.AUemmCH4hTD3lC4RWtG','Siswa',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('2a46131c-0921-42c4-8e92-0cf85a9496fb',NULL,NULL,'1000031','$2y$10$2dZWWnjOMT1puGNsde3sheIvjkY99M76PWbowC6K1sxw/19ObUzh.','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('2c505a4f-be58-4c01-9a89-89e7a199aa6f',NULL,NULL,'1000040','$2y$10$Lv6Bqc0ulRmwDFti.Z7eYe8S5rj1yZEsGjvva5QUs7dxFNCd0Kyz6','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('2d31704c-3567-49b7-9320-a9ca42ec4c5d',NULL,NULL,'1000017','$2y$10$.MUgurYYDqgC5TUxXblDA.kdgpipYIFpnYie3.FeQa5clZtk6Qe0O','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('300ac9f8-7686-4e98-9f14-efca044db274',NULL,NULL,'2000003','$2y$10$gndsqxpCO7vWmTYhYTRHzeDPdf7IjZTqpqeHfGl/YtR2PpnnylLCK','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('31748004-19f4-49e4-bf95-c014f0d820e7',NULL,NULL,'1000037','$2y$10$LLg.M3ZwvGGMsZq4Viy7f.FPGKukJckU7PadZqxXUcmf0IH/lebs.','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('332d1185-7253-475c-ab3a-88f71333e516',NULL,NULL,'1000004','$2y$10$vBn7x6fpj28VorGWljL7oe.atUNlNKDRJiB1PSbvaD6lMumjfQnQy','Admin',NULL,NULL,'2024-12-20 21:48:50','2024-12-20 21:48:50'),
('3a8eb897-254e-4474-b722-8cb6fff9e249',NULL,NULL,'1000054','$2y$10$bSvubHRQ8QOHIjyMXFXYueevZ6QtAdpClCL1qzWKdSsa023JS65NG','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('3eff5d3a-1809-4653-b65d-d77695050d24',NULL,NULL,'1000013','$2y$10$ssiN.9oSrY3eesKc.ahLAejewBcBVB1GPtSzNKM1tnq9iziIpqvyS','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('42451e82-982c-45c2-a24c-864173968d83',NULL,NULL,'1000035','$2y$10$lSTWLOyZ5bwRP01R12I9OuKPt0n23C8iSIKTlWqtMuf515Ib72UGi','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('43dcbdab-af01-4617-bed0-3cbefe970426',NULL,NULL,'1000029','$2y$10$DsQJbBUmS6.sVQVrnFCDYONOqbaZwI0XnO8tvXC7XYSOksyX15ap2','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('478d6435-3c69-433d-a1b3-e0edbf3f7b3f',NULL,NULL,'1000007','$2y$10$/1qcd4lqj1Ggmv/HcDRFiOjgfz5ILQecwklJ0L5j2oqTmKzDoDZum','Admin',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('4a959600-591c-4750-9dfd-aa70558554fc',NULL,NULL,'1000016','$2y$10$CyQmhX.DS75Wl.69doKe/O6/wM.IE4fHgXaBeGiR1BUWWTMwKJ6vu','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('4c9d2813-c56a-4c19-a2c5-1350faeb3613',1,NULL,'edwinsirait','$2y$10$bi7KAUGQpPYraclyRBznQ.WzfNR1wlveNNmkW/MuK1jZnrdp6C.sW','Admin','SU,Admin,Guru,Kurikulum,KepalaSekolah',NULL,'2024-12-20 21:48:57','2025-01-17 18:21:21'),
('4ca4d367-c647-490d-991f-c63e5025182e',NULL,NULL,'2000006','$2y$10$JNGSGDIxcBWWMPonKdAbRuR7N.GWuYyj.xT7r7SleFWYylJN5YwLi','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('4ee4488f-292a-4a6c-9a45-fe1fc094d398',NULL,1,'2000000','$2y$10$blVPcyyz4oHw3O3wCUbVBuE/UFEy8AQBbic6qvyNjKl5V1wYsIUiC','Siswa','Siswa',NULL,'2024-12-20 21:48:56','2025-01-15 22:39:26'),
('55d4c83b-561a-42c3-8279-af0435155ebe',NULL,NULL,'1000024','$2y$10$LxNmN/tly2NIgpbm3xIDk..M8AqyXJcZZeE62qaIYB3D2wxEZBX5G','Guru',NULL,NULL,'2024-12-20 21:48:53','2024-12-20 21:48:53'),
('572ffc28-a37b-470f-84b8-861cfd0710bd',NULL,NULL,'1000021','$2y$10$UF9OcwXbLT86SmM4XatCUeDekuUcpiNUDsSP3bMz18GWSPdva4tbe','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('58c48728-e605-4b53-9c99-8f90bfd4c6bb',NULL,NULL,'1000046','$2y$10$IvAIqGV2QPyN9vJr3mOoDumb6hHKSsCj0eSrtpdZDeuykR7SHyQku','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('5ddcfbd9-750a-4a57-a7f3-7f75dac9aef9',NULL,NULL,'1000011','$2y$10$8J/bmOb8wqaVY7Od0Ar50ut8z/EAP6cNufH9g7rXCHY.sjc/PMYdK','Guru',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('5e1ca2a1-8619-4132-ba31-0af7806d9e3d',NULL,4,'sultoni12345','$2y$10$4kS97hrUNLXpoBkMzN2S6.Jn2kGaZtTsvGwb7bKItMoF9/29mu5J.','NonSiswa','NonSiswa',NULL,'2025-01-21 15:30:16','2025-01-22 10:26:49'),
('5f05fa26-2db6-44d3-af10-e7f7124499c8',NULL,NULL,'2000004','$2y$10$W8HaVDtSow4wR0j4HDSYGeu.3R4/acHKa7nHr4IuhkYh9P8cThVKa','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('5fe32603-a948-42a2-ae5c-3241c3f0a2f4',NULL,NULL,'2000009','$2y$10$/kS/S4dc4lczHwz90Lj5HeIjqh/mW15CASs3XX.EIEQYxa8/fqCuy','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('66bc5455-5887-47a4-a5d4-91bb10fea6d8',NULL,NULL,'2000010','$2y$10$Bumn9B4TrLZduw9wMiXewOgDpgI/TKJg6EGxjXpY2CxwK1NjbO8OS','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('67ba59f6-ebe0-4f9f-8d8d-6b4a2c7acf7c',NULL,NULL,'1000042','$2y$10$h.e71ClPx1opcZyaGvkxR.88hNpCFtECZoHB9Olw.fp5L/X9tdK5S','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('701fbaeb-ea75-4414-8cda-1260daddefe5',NULL,NULL,'1000018','$2y$10$crETq0gr.2X2gI.Tddj1.OSJlb0wCQVCNfIZXq3IJAOPHE0rp7Uea','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('77b1d578-b328-4b3e-8cc7-024920193040',NULL,NULL,'1000048','$2y$10$i7OOSwo5e3nAGhCoP1HWJ.Y6xX8lJfKI6QTlKXCxht76ImDdkIsAi','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('79e18bb8-4fc7-4114-ad4e-93e0e7f47346',NULL,NULL,'1000030','$2y$10$swvKUiAvHhWToDNqdc9sY.Fd3CfDw/nN8lduLJ6/ORlSqsPqz5u4q','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('7b0f7953-505d-4712-a3ad-c99c938143a9',NULL,NULL,'1000003','$2y$10$ep0vJJ2f0jMO8QS7DyliQuABzEb362IzzVsJXbNsrLYpWvhMl47R.','Admin','Guru',NULL,'2024-12-20 21:48:50','2024-12-20 21:48:50'),
('7c58a6fc-b642-4795-a63b-b61e98abb1fd',NULL,NULL,'1000028','$2y$10$/uUTjtMvtW05ZmR81d3QTeTrqtXw5yIyTCWbCIMowvmG6xAo9szTO','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('7d060456-1eba-4a04-b3b3-ca63178afc74',NULL,NULL,'1000027','$2y$10$4jSRae0ajC3TfL3xm8D2AO.SGdrxjiIXgcUH2ybmCEHqPpHNk4wtK','Guru',NULL,NULL,'2024-12-20 21:48:53','2024-12-20 21:48:53'),
('7d329448-a1bf-4812-b3dc-07d1ce4e304d',NULL,2,'2000001','$2y$10$UaIui/rv1V1rkgtZCwwt7uUgDV3LBevZuXWd.lRv0c0kavR.LUSb.','Siswa','Siswa',NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('7e453e96-898a-4c19-953d-23fcf3c5759e',NULL,NULL,'1000022','$2y$10$5v5jewjK.hjB5i1lsBZEJulTwl.RS7ESIrSyxNKHCUyMA4JK.xCD.','Guru',NULL,NULL,'2024-12-20 21:48:53','2024-12-20 21:48:53'),
('7feb852c-cb0f-42c8-8f83-36ee84ad50e2',NULL,NULL,'1000047','$2y$10$/iZd7nPS3jDOL8bBW0ytcOeGkIvky9jeyViIAO3OaXC7q3t2pIlru','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('80d5e6fd-fec9-4624-9a65-40c015192033',NULL,NULL,'2000008','$2y$10$m9Ee4Uk.Hx6PAQ.DsIvsaeQLXvOO3ABapU38LFxtjwvSyh8xtGBDm','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('9342011c-764e-4be1-8008-35fad8120429',NULL,NULL,'1000041','$2y$10$5if0guq6k4OUIQL3z71/6uyjBHOD4sMrvGPFacvCPdEXbNwFbJUBC','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('a01ffc60-3492-453d-9683-4155d8feaf5b',NULL,NULL,'1000020','$2y$10$MKDyV8o/M1dNZU5LKY6Zu.L.74RoO/JQaDoOybP7GjR4xYXFm6V/2','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('aae7e2f1-902e-45d3-9605-bb1a97c95431',NULL,NULL,'1000053','$2y$10$LLm0ubLjZSuy45.P4eAwUujWOHGANYzvlf9m5hsSuSX65TyAAzw72','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('ab891990-2d00-4afc-a575-dcd37a97a73d',NULL,NULL,'1000006','$2y$10$nfiYrfhddIUlE1Sy8J0z/.OD8rG/LOHM62Q3X4maPMnp5qy6Ahhmq','Guru',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('b1adc1cd-1691-47c9-8091-3f8ae73ffc7a',NULL,NULL,'2000005','$2y$10$GnfEOtuF6Z0hmJIPUNf7BOZawuH1lxp0aqsMI7I23RlY5yLKH8J8a','Siswa',NULL,NULL,'2024-12-20 21:48:57','2024-12-20 21:48:57'),
('b75a4956-b8d2-4ef4-b880-80da82239796',NULL,NULL,'1000014','$2y$10$TzprgB9ihj1mzcLJ0RvVpuXgvKEz15Mx4YIPCdx4qpyiGPb9xEOQW','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('b7ab94d1-443a-4fd3-8c7e-3302ff94e476',NULL,NULL,'1000008','$2y$10$xGwu.DGZyiYeNdFm8ObG..Boi1Fsqgn5I5fLuuFTFsZdwrPzeXxIS','Guru',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('bd538045-14fb-42d0-b2e5-cea90462ee79',NULL,NULL,'1000009','$2y$10$iJSSG3TWiSRN8uSCK24uHuau8NjB6MeNbOWQxsfyRfphOaJGDGI.K','Guru',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('bed91380-8fa2-4ff3-8cce-871368acf52e',NULL,NULL,'1000005','$2y$10$b0VUfeS32J3vTMEqFigIIeMnRinXUD/byQcEHRF6WVlzCKPdzW79.','Admin',NULL,NULL,'2024-12-20 21:48:50','2024-12-20 21:48:50'),
('cb383a81-0565-4bed-9528-0fa8d72f0478',NULL,NULL,'1000034','$2y$10$ILwLJVrib0HhFNorjGSzgulsY0QZrCm.IK/u7d40YP4.3MwDJIHI6','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('cc733f61-6419-4f62-9cd8-e107b7c04b8f',NULL,NULL,'1000050','$2y$10$Iv3BSg3yRMbeBQsbRrZJbuwC.UJHlwz9Q2hC4mLN94qJWltMWeKIe','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('cf251027-ae02-4e24-825b-d89123daf4ce',NULL,NULL,'1000051','$2y$10$3i7mH3oNx6RejqA4ELWXmOmqEseOnALFAj.h2ThtEPh4jxhrebJ/e','Guru',NULL,NULL,'2024-12-20 21:48:56','2024-12-20 21:48:56'),
('d7de6cdd-329f-4cac-8088-367a3d8bd42a',NULL,NULL,'1000045','$2y$10$gF0zhYFulK9YZJwFcb/G2eUNysPND.ibB3m9JsieelQHFmZFF1mZq','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('da545f7c-0591-4a8e-9bb4-e8c67e43c0d1',NULL,NULL,'1000012','$2y$10$pZdsHKKekmW5LxV3myv8F.bJz//MZIMDXJg/LQIubhQYBo3NYwJWG','Guru',NULL,NULL,'2024-12-20 21:48:51','2024-12-20 21:48:51'),
('dd0dd982-60fb-419a-ad60-f35e1e339634',NULL,NULL,'1000019','$2y$10$WbCT7By89oYQ7xaMfDUtmewjAmbsFooteThMMuRv4IaqCKekfZl/C','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('ddcec0ab-5838-472b-ad51-4fe767d22da9',NULL,NULL,'1000039','$2y$10$m.QXwbyls2fXx5B/97AJ6uk6QIks/Gx5BdV/C/ZkWmTUftEH6Hnt.','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('e9b2378c-52e4-469c-b2d4-af6f1014a373',NULL,NULL,'1000036','$2y$10$5f7XU1Y1Q1sLvR3OMHj73.n97b4FLJuN8PloQ5IvLJ7ViIdVSDPdy','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('ea8d43b2-d831-4efd-9c9c-2f814bc8b172',NULL,6,'1905551166','$2y$10$9Q9vmyxKYxb3FBnWvyMageNUjXu4U9TTlFC54sJpZFW4GW9FwFeTS','NonSiswa','NonSiswa',NULL,'2025-01-22 11:32:34','2025-01-22 14:54:08'),
('ee8db29f-ec26-4401-8c69-6c05daedeb32',NULL,NULL,'1000015','$2y$10$FssqHH6uztPGOIWXQHUyQOyUw74grGqn5puVWjjACdUyQw.9QTv2a','Guru',NULL,NULL,'2024-12-20 21:48:52','2024-12-20 21:48:52'),
('f0b6989a-a4d5-438d-b5bc-7be79e2e5312',NULL,NULL,'1000026','$2y$10$lsqH0S2/Qv/fl2KIeHyLaeJ0gHAeTzSsELz1ARn63wpVTyc61gnOa','Guru',NULL,NULL,'2024-12-20 21:48:53','2024-12-20 21:48:53'),
('f2065c77-89a5-401c-9670-8e8bed86be4b',NULL,NULL,'1000002','$2y$10$yYR.Bz0cRpHFcT1ySukRuuKVOujzQizaK.NSjyluhkb/qSpqKYi5m','Admin','Kurikulum',NULL,'2024-12-20 21:48:49','2024-12-20 21:48:49'),
('f2492162-9f48-45d3-95e8-851a091c43e0',NULL,NULL,'1000001','$2y$10$N14ZJrvuqx04rk2SGXKqcuMh0GNOanSWgBaUB.p5mJAHj/AaONCTq','Kurikulum','Admin,Guru,Kurikulum,KepalaSekolah',NULL,'2024-12-20 21:48:49','2025-01-17 15:56:24'),
('f7aa8045-ec81-4fbc-87d6-e6587328dc51',NULL,NULL,'1000044','$2y$10$6mIhQouZw749pPPm6TkKWeDs9B4ntnTt5pSA1Vkz5PmCJj2KRou4C','Guru',NULL,NULL,'2024-12-20 21:48:55','2024-12-20 21:48:55'),
('fc08558a-10b0-46b3-a3b2-3679791f7a00',NULL,NULL,'1000033','$2y$10$XLKWT1/vjAo5YMQkQJe1zO82oxEy6qFkEXcgYpCTHaiIS4bHSSTlO','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54'),
('ff2cad70-cb3d-41f0-96e6-7f4da9e5180e',NULL,NULL,'1000032','$2y$10$7V0.Co7zVej7HTV7niszg.IoT7aVgRp3eNmqDtqjQjLx7yRKuYVjy','Guru',NULL,NULL,'2024-12-20 21:48:54','2024-12-20 21:48:54');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
